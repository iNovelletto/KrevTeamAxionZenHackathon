﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace MasterMindApi.Models
{
    public class MasterMindContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public MasterMindContext():base("DefaultConnection")
        {

        }
    }
}