﻿$(document).ready(function () {
    //$("#btnSubmit").click(createUserApi);
    //$("#btnSubmit").click(createNewGame);
    //$("#btnSubmit").click(createWaitPlay);
    //$("#btnSubmit").click(createPlay);
    //$("#btnSubmit").click(createWaitPlay);
});

